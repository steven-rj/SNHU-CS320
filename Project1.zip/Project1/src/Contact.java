package src;

public class Contact
{
	private String id;
	private String firstName;
	private String lastName;
	private String Address;
	private String Number;
	
	public Contact(String id, String firstName, String lastName, String Address, String Number)
	{
		if (id == null || id.length() > 10)
		{
			throw new IllegalArgumentException("Invalid id");
		}
		
		if (firstName == null || firstName.length() > 10)
		{
			throw new IllegalArgumentException("Invalid first name");
		}
		
		if (lastName == null || lastName.length() > 10)
		{
			throw new IllegalArgumentException("Invalid last name");
		}
		
		if (Address == null || Address.length() > 30)
		{
			throw new IllegalArgumentException("Invalid address");
		}
		
		if (Number == null || Number.length() > 10)
		{
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.Address = Address;
		this.Number = Number;
	}
	
	public String getId()
	{
		return id;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setFirstName(String name)
	{
		this.firstName = name;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public void setLastName(String name)
	{
		this.lastName = name;
	}
	
	public String getAddress()
	{
		return Address;
	}
	
	public void setAddress(String address)
	{
		this.Address = address;
	}
	
	public String getNumber()
	{
		return Number;
	}
	
	public void setNumber(String number)
	{
		this.Number = number;
	}
		
}