package src;

import java.util.ArrayList;

public class ContactService
{
	private ArrayList<Contact> contacts;
	
	public ContactService()
	{
		contacts = new ArrayList<>();
	}
	
	public boolean addContact(Contact contact)
	{
		boolean alreadyAdded = false;
		
		for (Contact contactList : contacts)
		{
			if (contactList.equals(contact))
			{
				alreadyAdded = true;
			}
		}
		
		if (!alreadyAdded)
		{
			contacts.add(contact);
			return true;
		}
		else
		{
			return false;
		}
	}
		
	public boolean deleteContact(String id)
	{
        for (Contact contactList : contacts)
        {
            if (contactList.getId().equals(id))
            {
                contacts.remove(contactList);
                return true;
            }
        }
        return false;
    }
	
	public boolean updateContact(String contactId, String newFirst, String newLast, String newAddress, String newPhone)
	{
        for (Contact contactList : contacts)
        {
            if (contactList.getId().equals(contactId))
            {
                if (!newFirst.equals("") && !(newFirst.length() > 10)) {
                    contactList.setFirstName(newFirst);
                }
                if (!newLast.equals("") && !(newLast.length() > 10))
                {
                    contactList.setLastName(newLast);
                }
                if (!newAddress.equals("") && !(newAddress.length() > 30))
                {
                	contactList.setAddress(newAddress);
                }
                if (!newPhone.equals("") && !(newPhone.length() > 10))
                {
                	contactList.setNumber(newPhone);
                }
                return true;
            }
        }
        return false;
    }
}