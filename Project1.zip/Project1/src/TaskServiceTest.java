package src;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import src.Task;
import src.TaskService;

class TaskServiceTest
{
	@Test
	public void testAddTask()
	{
		TaskService taskServ = new TaskService();
		Task task1 = new Task("01", "Test Task 1", "Created by the TaskServiceTest");
		assertEquals(true, taskServ.addTask(task1));
	}
	
	@Test
	public void testDelete()
	{
		TaskService taskServ = new TaskService();
		
		Task task1 = new Task("01", "Test Task 1", "Created by testDelete");
		Task task2 = new Task("02", "Test Task 2", "Created by testDelete");
		
		taskServ.addTask(task1);
		taskServ.addTask(task2);
		
		assertEquals(true, taskServ.deleteTask("01"));
		assertEquals(true, taskServ.deleteTask("02"));
	}
	
	@Test
	public void testUpdate()
	{
		TaskService taskServ = new TaskService();
		
		Task task1 = new Task("01", "Test Task 1", "Created by testUpdate");
		Task task2 = new Task("02", "Test Task 2", "Created by testUpdate");
		
		taskServ.addTask(task1);
		taskServ.addTask(task2);
		
		assertEquals(true, taskServ.updateTask("01", "New Task 1", "reCreated by testUpdate"));
		assertEquals(true, taskServ.updateTask("02", "New Task 2", "reCreated by testUpdate"));
	}
}