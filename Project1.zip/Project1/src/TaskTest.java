package src;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import src.Task;

class TaskTest
{

	@Test
	void testTask()
	{
		Task newTask = new Task("01", "Test", "This is just a test!");
		assertTrue(newTask.getTaskName().equals("Test"));
		assertTrue(newTask.getTaskDescription().equals("This is just a test!"));
		assertTrue(newTask.getTaskId().equals("01"));
	}
	
	@Test
	void testIdTooLong()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Task("012345678999", "ID Long Test", "This will test if ID is too long");
		});
	}
	
	@Test
	void testIdIsNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Task(null, "ID Null Test", "This will test if ID is null");
		});	
	}
	
	@Test
	void testNameTooLong()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Task("01", "The official waaaay too long Name test", "This will test if ID is too long");
		});
	}
	
	@Test
	void testNameIsNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Task("01", null, "This will test if name is null");
		});	
	}
	
	@Test
	void testDescriptionTooLong()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Task("01", "Descrip Long Test", "This is the description that never ends, because it goes on and on and on and on my frieeeeeends!");
		});
	}
	
	@Test
	void testIdDescriptionNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Task("01", "Description Null Test", null);
		});	
	}
	
	@Test
	void testReturnTaskName()
	{
		Task newTask = new Task("01", "Test", "This is just a test!");
		newTask.setTaskName("new name");
		assertTrue(newTask.getTaskName().equals("new name"));		
	}
	
	@Test
	void testReturnTaskDescription()
	{
		Task newTask = new Task("01", "Test", "This is just a test!");
		newTask.setTaskDescription("changed it!");
		assertTrue(newTask.getTaskDescription().equals("changed it!"));		
	}

}