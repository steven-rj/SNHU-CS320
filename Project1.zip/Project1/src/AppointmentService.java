package src;

import java.util.ArrayList;

public class AppointmentService
{
	private ArrayList<Appointment> appointments;
	
	public AppointmentService()
	{
		appointments = new ArrayList<>();
	}
	
	public boolean addAppointment(Appointment appointment)
	{
		boolean alreadyAdded = false;
		
		for (Appointment apptList : appointments)
		{
			if (apptList.equals(appointment))
			{
				alreadyAdded = true;
			}
		}
		
		if (!alreadyAdded)
		{
			appointments.add(appointment);
			return true;
		}
		else
		{
			return false;
		}
	}
		
	public boolean deleteAppointment(String id)
	{
        for (Appointment apptList : appointments)
        {
            if (apptList.getAppointmentId().equals(id))
            {
                appointments.remove(apptList);
                return true;
            }
        }
        return false;
    }
}
