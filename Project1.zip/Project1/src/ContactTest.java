package src;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import src.Contact;

class ContactTest
{
		@Test
		void testContactClass()
		{
			Contact contactClass = new Contact("01", "Steven", "Jordan", "123 My Place St.", "8031234567");
			assertTrue(contactClass.getId().equals("01"));
			assertTrue(contactClass.getFirstName().equals("Steven"));
			assertTrue(contactClass.getLastName().equals("Jordan"));
			assertTrue(contactClass.getAddress().equals("123 My Place St."));
			assertTrue(contactClass.getNumber().equals("8031234567"));
		}
		
		@Test
		void testContactClassIdTooLong()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("00000000001", "Steven", "Jordan", "123 My Place St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassFirstNameTooLong()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", "Stevennnnnnn", "Jordan", "123 My Place St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassLastNameTooLong()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", "Steven", "Jordannnnnnn", "123 My Place St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassAddressTooLong()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", "Steven", "Jordan", "123456789 My Lovely Place Not On The Moon St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassPhoneTooLong()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("00000000001", "Steven", "Jordan", "123 My Place St.", "803123456789");
			});
		}
		
		@Test
		void testContactClassIdIsNull()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact(null, "Steven", "Jordan", "123 My Place St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassFirstNameIsNull()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", null, "Jordan", "123 My Place St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassLastNameIsNull()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", "Steven", null, "123 My Place St.", "8031234567");
			});
		}
		
		@Test
		void testContactClassAddressIsNull()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", "Steven", "Jordan", null, "8031234567");
			});
		}
		
		@Test
		void testContactClassPhoneIsNull()
		{
			Assertions.assertThrows(IllegalArgumentException.class, () ->
			{
				new Contact("01", "Steven", "Jordan", "123 My Place St.", null);
			});
		}
		
		@Test
		void testFirstName()
		{
			Contact contactTest = new Contact("01", "Steven", "Jordan", "123 My Place St.", "8031234567");
			contactTest.setFirstName("Ryan");
			assertTrue(contactTest.getFirstName().equals("Ryan"));
		}
		
		@Test
		void testLastName()
		{
			Contact contactTest = new Contact("01", "Steven", "Jordan", "123 My Place St.", "8031234567");
			contactTest.setLastName("Jackson");
			assertTrue(contactTest.getLastName().equals("Jackson"));
		}
		
		@Test
		void testPhoneNumber()
		{
			Contact contactTest = new Contact("01", "Steven", "Jordan", "123 My Place St.", "8031234567");
			contactTest.setNumber("8038675309");
			assertTrue(contactTest.getNumber().equals("8038675309"));
		}
		
		@Test
		void testAddress()
		{
			Contact contactTest = new Contact("01", "Steven", "Jordan", "123 My Place St.", "8031234567");
			contactTest.setAddress("705 South Whaley");
			assertTrue(contactTest.getAddress().equals("705 South Whaley"));
		}
}