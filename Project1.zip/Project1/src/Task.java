package src;

public class Task
{
	private String taskId;
	private String taskName;
	private String taskDescription;
	
	public Task( String taskId, String taskName, String taskDescription)
	{
		if (taskId == null || taskId.length() > 10)
		{
			throw new IllegalArgumentException("Invalid ID!");
		}
		
		if (taskName == null || taskName.length() > 20)
		{
			throw new IllegalArgumentException("Invalid Name!");
		}
		
		if (taskDescription == null || taskDescription.length() > 50)
		{
			throw new IllegalArgumentException("Invalid Description!");
		}
		
		this.taskName = taskName;
		this.taskDescription = taskDescription;
		this.taskId = taskId;
	}
	
	public String getTaskName()
	{
		return taskName;
	}
	
	public void setTaskName(String name)
	{
		this.taskName = name;
	}
	
	public String getTaskDescription()
	{
		return taskDescription;
	}
	
	public void setTaskDescription(String desc)
	{
		this.taskDescription = desc;
	}
	
	public String getTaskId()
	{
		return taskId;
	}
}
