package src;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import src.Appointment;

class AppointmentTest
{

	@Test
	void testAppointment()
	{
		Appointment newAppt = new Appointment("01", new Date(01-01-23), "This is just a test!");
		assertTrue(newAppt.getAppointmentId().equals("01"));
		assertTrue(newAppt.getAppointmentDate().equals(new Date(01-01-23)));
		assertTrue(newAppt.getAppointmentDescription().equals("This is just a test!"));
	}
	
	@Test
	void testIdTooLong()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Appointment("012345678999", new Date(03-30-23), "This will test if ID is too long");
		});
	}
	
	@Test
	void testIdIsNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Appointment(null, new Date(03-03-23), "This will test if ID is null");
		});	
	}
	
	@Test
	void testDatePassed()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Appointment("01", new Date(01-01-01), "This will test if the provided date has already occured");
		});
	}
	
	@Test
	void testDateNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Appointment("01", null, "This will test if the date is null.");
		});	
	}
	
	@Test
	void testDescriptionTooLong()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Appointment("01", new Date(03-03-23), "This is the description that never ends, because it goes on and on and on and on my frieeeeeends!");
		});
	}
	
	@Test
	void testIdDescriptionNull()
	{
		Assertions.assertThrows(IllegalArgumentException.class, () ->
		{
			new Appointment("01", new Date(03-03-23), null);
		});	
	}
}