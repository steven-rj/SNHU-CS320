package src;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

import src.Appointment;
import src.AppointmentService;

class AppointmentServiceTest
{
	@Test
	public void testAddAppointment()
	{
		AppointmentService apptServ = new AppointmentService();
		Appointment appt1 = new Appointment("01", new Date(03-03-23), "Created by the ApptServiceTest");
		assertEquals(true, apptServ.addAppointment(appt1));
	}
	
	@Test
	public void testDeleteAppointment()
	{
		AppointmentService apptServ = new AppointmentService();
		
		Appointment appt1 = new Appointment("01", new Date(04-01-23), "Created by testDelete");
		Appointment appt2 = new Appointment("02", new Date(03-02-23), "Created by testDelete");
		
		apptServ.addAppointment(appt1);
		apptServ.addAppointment(appt2);
		
		assertEquals(true, apptServ.deleteAppointment("01"));
		assertEquals(true, apptServ.deleteAppointment("02"));
	}
}