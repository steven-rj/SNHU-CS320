package src;

import java.util.Date;

public class Appointment
{
	private String apptId;
	private Date apptDate;
	private String apptDescription;
	
	public Appointment( String apptId, Date apptDate, String apptDescription)
	{
		if (apptId == null || apptId.length() > 10)
		{
			throw new IllegalArgumentException("Invalid ID!");
		}
		
		if (apptDate == null || apptDate.before(new Date(01-01-23)))
		{
			throw new IllegalArgumentException("Invalid Date!");
		}
		
		if (apptDescription == null || apptDescription.length() > 50)
		{
			throw new IllegalArgumentException("Invalid Description!");
		}
		
		this.apptDate = apptDate;
		this.apptDescription =apptDescription;
		this.apptId = apptId;
	}
	
	public String getAppointmentId()
	{
		return apptId;
	}
	
	public String getAppointmentDescription()
	{
		return apptDescription;
	}
	
	public Date getAppointmentDate()
	{
		return apptDate;
	}
	

}
