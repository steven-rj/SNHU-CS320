package src;

import java.util.ArrayList;

public class TaskService
{
	private ArrayList<Task> tasks;
	
	public TaskService()
	{
		tasks = new ArrayList<>();
	}
	
	public boolean addTask(Task task)
	{
		boolean alreadyAdded = false;
		
		for (Task taskList : tasks)
		{
			if (taskList.equals(task))
			{
				alreadyAdded = true;
			}
		}
		
		if (!alreadyAdded)
		{
			tasks.add(task);
			return true;
		}
		else
		{
			return false;
		}
	}
		
	public boolean deleteTask(String id)
	{
        for (Task taskList : tasks)
        {
            if (taskList.getTaskId().equals(id))
            {
                tasks.remove(taskList);
                return true;
            }
        }
        return false;
    }
	
	public boolean updateTask(String taskId, String newName, String newDescription)
	{
        for (Task taskList : tasks)
        {
            if (taskList.getTaskId().equals(taskId))
            {
                if (!newName.equals("") && !(newName.length() > 10)) {
                    taskList.setTaskName(newName);
                }
                if (!newDescription.equals("") && !(newDescription.length() > 50))
                {
                    taskList.setTaskDescription(newDescription);
                }
                return true;
            }
        }
        return false;
    }
}

