package src;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import src.Contact;
import src.ContactService;

class ContactServiceTest
{
	@Test
	public void testAddContact()
	{
		ContactService contactServ = new ContactService();
		Contact contact1 = new Contact("01", "Steven", "Jordan", "123 Whaley Pl.", "8034567890");
		assertEquals(true, contactServ.addContact(contact1));
	}
	
	@Test
	public void testDelete()
	{
		ContactService contactServ = new ContactService();
		
		Contact contact1 = new Contact("01", "Steven", "Jordan", "123 Whaley Pl.", "8031234567");
		Contact contact2 = new Contact("02", "Amy", "Shumate", "98 Brighton Way", "1234567890");
		
		contactServ.addContact(contact1);
		contactServ.addContact(contact2);
		
		assertEquals(true, contactServ.deleteContact("01"));
		assertEquals(true, contactServ.deleteContact("02"));
	}
	
	@Test
	public void testUpdate()
	{
		ContactService contactServ = new ContactService();
		
		Contact contact1 = new Contact("01", "Steven", "Jordan", "123 Whaley Pl.", "8031234567");
		Contact contact2 = new Contact("02", "Amy", "Shumate", "98 Brighton Way", "1234567890");
		
		contactServ.addContact(contact1);
		contactServ.addContact(contact2);
		
		assertEquals(true, contactServ.updateContact("01", "Stephanie", "Jackson", "125 Whaley Pl.", "8039087654"));
		assertEquals(true, contactServ.updateContact("02", "Aimee", "Smart", "98 Triton Path", "9081234567"));
	}
}